-- Alternative to IVFFlat. Do not keep both indexes unless you intentionally test both.

DROP INDEX IF EXISTS ai_docs_embedding_half_ivfflat_idx;
DROP INDEX IF EXISTS ai_docs_embedding_half_hnsw_idx;

CREATE INDEX ai_docs_embedding_half_hnsw_idx
ON ai_docs
USING hnsw (embedding_half halfvec_cosine_ops)
WITH (m = 16, ef_construction = 64);

ANALYZE ai_docs;
