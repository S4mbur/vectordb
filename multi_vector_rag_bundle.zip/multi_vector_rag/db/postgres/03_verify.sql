SELECT extname, extversion FROM pg_extension WHERE extname = 'vector';

SELECT column_name, data_type, udt_name
FROM information_schema.columns
WHERE table_name = 'ai_docs'
ORDER BY ordinal_position;

SELECT indexname, indexdef
FROM pg_indexes
WHERE tablename = 'ai_docs'
ORDER BY indexname;

SELECT COUNT(*) AS rows, COUNT(DISTINCT file_name) AS files FROM ai_docs;
