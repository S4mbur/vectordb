#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
if [[ -f "$ROOT_DIR/.env" ]]; then
  set -a
  # shellcheck disable=SC1091
  source "$ROOT_DIR/.env"
  set +a
fi

ES_URL="${ES_URL:-http://127.0.0.1:9200}"
ES_INDEX="${ES_INDEX:-ai_docs_elasticsearch}"
AUTH_ARGS=()

if [[ -n "${ES_API_KEY:-}" ]]; then
  AUTH_ARGS=(-H "Authorization: ApiKey ${ES_API_KEY}")
elif [[ -n "${ES_USERNAME:-}" && -n "${ES_PASSWORD:-}" ]]; then
  AUTH_ARGS=(-u "${ES_USERNAME}:${ES_PASSWORD}")
fi

TLS_ARGS=()
if [[ "${ES_VERIFY_CERTS:-false}" != "true" ]]; then
  TLS_ARGS=(-k)
elif [[ -n "${ES_CA_CERTS:-}" ]]; then
  TLS_ARGS=(--cacert "${ES_CA_CERTS}")
fi

if curl -fsS "${TLS_ARGS[@]}" "${AUTH_ARGS[@]}" "$ES_URL/$ES_INDEX" >/dev/null 2>&1; then
  echo "Elasticsearch index already exists: $ES_INDEX"
else
  curl -fsS "${TLS_ARGS[@]}" "${AUTH_ARGS[@]}" \
    -H 'Content-Type: application/json' \
    -X PUT "$ES_URL/$ES_INDEX" \
    --data-binary "@$ROOT_DIR/db/elasticsearch/mapping.json"
  echo
  echo "Created Elasticsearch index: $ES_INDEX"
fi
