#!/usr/bin/env python3
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from app import MILVUS_COLLECTION, connect_milvus  # noqa: E402
from pymilvus import Collection, utility  # noqa: E402

connect_milvus()
if not utility.has_collection(MILVUS_COLLECTION):
    raise SystemExit(f"Collection does not exist: {MILVUS_COLLECTION}")
collection = Collection(MILVUS_COLLECTION)
print("Collection:", collection.name)
print("Schema:", collection.schema)
print("Indexes:", collection.indexes)
print("Entities:", collection.num_entities)
