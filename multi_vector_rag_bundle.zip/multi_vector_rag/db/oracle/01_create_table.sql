-- Run as AI_RAG in the target PDB.

BEGIN
    EXECUTE IMMEDIATE q'[
        CREATE TABLE AI_DOCS_ORACLE (
            id NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
            file_name VARCHAR2(512) NOT NULL,
            chunk_index NUMBER NOT NULL,
            content CLOB NOT NULL,
            embedding VECTOR(4096, FLOAT32) NOT NULL,
            created_at TIMESTAMP DEFAULT SYSTIMESTAMP NOT NULL
        )
    ]';
EXCEPTION
    WHEN OTHERS THEN
        IF SQLCODE != -955 THEN -- object already exists
            RAISE;
        END IF;
END;
/

BEGIN
    EXECUTE IMMEDIATE 'CREATE INDEX AI_DOCS_ORACLE_FILE_IDX ON AI_DOCS_ORACLE(file_name)';
EXCEPTION
    WHEN OTHERS THEN
        IF SQLCODE != -955 THEN
            RAISE;
        END IF;
END;
/
