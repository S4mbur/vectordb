-- DML-friendly IVF / Neighbor Partitions index.
-- Prefer this over INMEMORY NEIGHBOR GRAPH for this continuously-uploaded demo.
-- Create after initial data load for better clustering quality.

BEGIN
    EXECUTE IMMEDIATE 'DROP INDEX AI_DOCS_ORACLE_VEC_IDX';
EXCEPTION
    WHEN OTHERS THEN
        IF SQLCODE != -1418 THEN -- index does not exist
            RAISE;
        END IF;
END;
/

CREATE VECTOR INDEX AI_DOCS_ORACLE_VEC_IDX
ON AI_DOCS_ORACLE (embedding)
ORGANIZATION NEIGHBOR PARTITIONS
DISTANCE COSINE
WITH TARGET ACCURACY 80;
