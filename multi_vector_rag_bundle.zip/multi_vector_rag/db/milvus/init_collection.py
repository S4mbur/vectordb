#!/usr/bin/env python3
"""Create the Milvus collection and vector index defined in .env."""

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from app import (  # noqa: E402
    EMBEDDING_DIM,
    MILVUS_COLLECTION,
    MILVUS_INDEX_TYPE,
    get_milvus_collection,
)

collection = get_milvus_collection()
print(
    f"Milvus ready: collection={collection.name}, "
    f"dimension={EMBEDDING_DIM}, index={MILVUS_INDEX_TYPE}"
)
