-- Run inside the application database (default: vector_rag).
-- The pgvector extension must already be installed on the PostgreSQL server.
-- Example:
--   psql -h 127.0.0.1 -U postgres -d vector_rag -f 01_create_extension_and_table.sql

CREATE EXTENSION IF NOT EXISTS vector;

CREATE TABLE IF NOT EXISTS ai_docs (
    id BIGSERIAL PRIMARY KEY,
    file_name TEXT NOT NULL,
    chunk_index INTEGER NOT NULL,
    content TEXT NOT NULL,
    embedding vector(4096) NOT NULL,
    embedding_half halfvec(2048) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS ai_docs_file_name_idx ON ai_docs (file_name);

GRANT SELECT, INSERT, UPDATE, DELETE, TRUNCATE ON ai_docs TO rag_user;
GRANT USAGE, SELECT ON SEQUENCE ai_docs_id_seq TO rag_user;

ANALYZE ai_docs;
