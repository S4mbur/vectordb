-- Recommended: load some data first, then create/recreate IVFFlat.
-- For small test datasets lists=1 is intentional. Increase it as data grows.
-- Official starting point: rows/1000 up to 1M rows, sqrt(rows) above 1M.

DROP INDEX IF EXISTS ai_docs_embedding_half_hnsw_idx;
DROP INDEX IF EXISTS ai_docs_embedding_half_ivfflat_idx;

SELECT GREATEST(
           1,
           CASE
               WHEN COUNT(*) <= 1000000 THEN CEIL(COUNT(*) / 1000.0)::integer
               ELSE CEIL(SQRT(COUNT(*)))::integer
           END
       ) AS lists
FROM ai_docs
\gset

CREATE INDEX ai_docs_embedding_half_ivfflat_idx
ON ai_docs
USING ivfflat (embedding_half halfvec_cosine_ops)
WITH (lists = :lists);

ANALYZE ai_docs;

SELECT :'lists' AS created_ivfflat_lists;
