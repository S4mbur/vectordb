# Multi Vector Database PDF RAG

Tek FastAPI uygulamasında aynı PDF-RAG akışını aşağıdaki backend'lerle karşılaştırır:

- PostgreSQL + pgvector
- Milvus
- Oracle AI Database / Vector Search
- Qdrant
- Elasticsearch

Uygulama PDF metnini çıkarır, sayfa/paragraph-aware chunk üretir, embedding API'ye batch gönderir, seçilen vector store'a yazar, soru için retrieval yapar, isteğe bağlı dedicated rerank modelinden geçirir ve son cevabı chat modeline ürettirir.

## Proje yapısı

```text
multi_vector_rag/
├── app.py
├── .env.example
├── requirements.txt
├── README.md
├── scripts/
│   ├── setup_python.sh
│   ├── start.sh
│   ├── init_non_sql_stores.py
│   └── check_services.py
└── db/
    ├── postgres/
    ├── oracle/
    ├── milvus/
    ├── qdrant/
    └── elasticsearch/
```

## 1. Python ortamı

```bash
cd multi_vector_rag
./scripts/setup_python.sh
cp .env.example .env   # setup script zaten yoksa kopyalar
vi .env
```

Manuel kurulum:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

## 2. PostgreSQL + pgvector

PostgreSQL sunucusunda `vector` extension binary/package olarak kurulu olmalıdır. Sonra:

```bash
# 00 dosyasındaki kullanıcı, parola ve DB adını düzenle
psql -h 127.0.0.1 -U postgres -d postgres \
  -f db/postgres/00_create_database_and_user.sql

psql -h 127.0.0.1 -U postgres -d vector_rag \
  -f db/postgres/01_create_extension_and_table.sql
```

Bu proje 4096 boyutlu full vector'ü saklar. pgvector ANN index boyut limiti nedeniyle ilk 2048 boyut ayrıca `halfvec(2048)` kolonunda tutulur:

1. `embedding_half` ile yaklaşık adaylar bulunur.
2. Bu adaylar full `embedding vector(4096)` ile exact yeniden sıralanır.

IVFFlat index'i mümkünse ilk veri yüklemesinden sonra oluştur:

```bash
psql -h 127.0.0.1 -U postgres -d vector_rag \
  -f db/postgres/02_create_ivfflat_index_after_load.sql
```

HNSW denemek için IVFFlat yerine:

```bash
psql -h 127.0.0.1 -U postgres -d vector_rag \
  -f db/postgres/02b_create_hnsw_index_alternative.sql
```

Kontrol:

```bash
psql -h 127.0.0.1 -U postgres -d vector_rag \
  -f db/postgres/03_verify.sql
```

Not: IVFFlat kullanırken `.env` içindeki `PG_IVFFLAT_PROBES` değerini index `lists` değerine göre ayarla. Küçük test verisinde `1`, daha büyük veride `sqrt(lists)` iyi bir başlangıçtır.

## 3. Oracle AI Database

Oracle yapın duruyorsa yalnızca verify script'ini çalıştırabilirsin. Baştan oluşturmak için hedef PDB'ye bağlan:

```sql
ALTER SESSION SET CONTAINER = FREEPDB1;
```

Ardından:

```bash
sqlplus / as sysdba @db/oracle/00_create_user.sql
sqlplus AI_RAG/CHANGE_ME@127.0.0.1:1521/FREEPDB1 @db/oracle/01_create_table.sql
```

İlk veri yüklemesinden sonra DML dostu IVF index:

```bash
sqlplus AI_RAG/CHANGE_ME@127.0.0.1:1521/FREEPDB1 \
  @db/oracle/02_create_ivf_vector_index.sql
```

Kontrol:

```bash
sqlplus AI_RAG/CHANGE_ME@127.0.0.1:1521/FREEPDB1 \
  @db/oracle/03_verify.sql
```

Uygulama `ORACLE_USE_APPROX_SEARCH=true` olduğunda sorguya `WITH TARGET ACCURACY` ekler. `false` yapıldığında `FETCH EXACT FIRST` kullanır.

## 4. Milvus

Milvus servisinin `19530` portunda çalışması yeterlidir. Collection ve index ilk kullanımda uygulama tarafından otomatik oluşturulur.

Manuel init:

```bash
source .venv/bin/activate
python db/milvus/init_collection.py
python db/milvus/verify.py
```

Index seçenekleri `.env`:

```env
MILVUS_INDEX_TYPE=HNSW
# veya FLAT / IVF_FLAT
```

Index tipini değiştirdiğinde eski collection'ı drop etmen ve PDF'leri yeniden yüklemen gerekir:

```bash
curl -X DELETE http://127.0.0.1:8080/milvus/clear
```

Milvus insert sırasında `flush()` batch başına değil, dosya başına yalnızca bir kez çalışır.

## 5. Qdrant

Qdrant binary/service `6333` portunda çalışıyorsa uygulama collection'ı otomatik oluşturur. Qdrant varsayılan vector index yapısını kullanır.

Manuel init ve kontrol:

```bash
./db/qdrant/create_collection.sh
./db/qdrant/verify.sh
```

Local URL örneği:

```env
QDRANT_HOST=127.0.0.1
QDRANT_PORT=6333
QDRANT_URL=
```

URL tabanlı bağlantı kullanacaksan `QDRANT_URL` doldurulur ve host/port ikinci planda kalır.

## 6. Elasticsearch

Elasticsearch `9200` portunda çalışmalıdır. Index ilk kullanımda otomatik oluşturulur.

Manuel init:

```bash
./db/elasticsearch/create_index.sh
./db/elasticsearch/verify.sh
```

Security açıksa `.env` içinde ya kullanıcı/parola ya da API key kullan:

```env
ES_USERNAME=elastic
ES_PASSWORD=CHANGE_ME
# veya
ES_API_KEY=
```

Mapping `dense_vector(4096)` + cosine kNN olarak oluşturulur.

## 7. Dedicated rerank modeli

Eski kod rerank için chat modelini tekrar çağırıyordu. Bu sürüm ayrı rerank endpoint/model kullanabilir.

Önerilen ayar:

```env
RERANK_MODE=api
RERANK_API_URL=https://YOUR-ENDPOINT/v1/rerank
RERANK_API_KEY=CHANGE_ME
RERANK_MODEL=YOUR_RERANK_MODEL
RERANK_API_STYLE=cohere
RERANK_MAX_CANDIDATES=12
RERANK_CHUNK_MAX_CHARS=1200
RERANK_FALLBACK=vector
```

### `cohere`, `jina` veya `generic` request formatı

```json
{
  "model": "YOUR_RERANK_MODEL",
  "query": "user question",
  "documents": ["chunk 1", "chunk 2"],
  "top_n": 5,
  "return_documents": false
}
```

Beklenen yaygın response biçimi:

```json
{
  "results": [
    {"index": 1, "relevance_score": 0.91},
    {"index": 0, "relevance_score": 0.63}
  ]
}
```

### TEI request formatı

```env
RERANK_API_STYLE=tei
```

Uygulama bu durumda `query` + `texts` gönderir. Response içindeki `index` ve `score` alanlarını okur.

Rerank endpoint'in farklı request formatı kullanıyorsa `call_rerank_api()` fonksiyonu tek düzenlenecek yerdir. Parser şu yaygın alanları destekler:

- Liste: `results`, `data`, `rankings`, `scores`
- Sıra: `index`, `id`, `document_index`
- Skor: `relevance_score`, `score`, `relevance`, `similarity`

Rerank kapatmak için:

```env
RERANK_MODE=none
```

Chat modeliyle eski rerank davranışı için:

```env
RERANK_MODE=llm
```

## 8. Non-SQL store'ları tek komutla hazırlama

Milvus, Qdrant ve Elasticsearch servisleri çalışıyorsa:

```bash
source .venv/bin/activate
python scripts/init_non_sql_stores.py
```

Tüm bağlantıları kontrol etmek için:

```bash
python scripts/check_services.py
```

## 9. Uygulamayı 8080'de çalıştırma

`.env.example` varsayılan olarak `APP_PORT=8080` içerir.

```bash
./scripts/start.sh
```

Alternatif:

```bash
source .venv/bin/activate
uvicorn app:app --host 0.0.0.0 --port 8080
```

Arayüz:

```text
http://SUNUCU_IP:8080/
```

Health endpoint:

```bash
curl http://127.0.0.1:8080/health
```

## 10. Önerilen ilk test sırası

1. `.env` içindeki embedding/chat/rerank endpoint ve model adlarını doldur.
2. PostgreSQL database/table yapısını kur.
3. Oracle mevcut yapıyı `03_verify.sql` ile kontrol et.
4. Milvus, Qdrant ve Elasticsearch servislerini başlat.
5. `python scripts/init_non_sql_stores.py` çalıştır.
6. `python scripts/check_services.py` çalıştır.
7. Uygulamayı 8080'de başlat.
8. Her backend'e aynı PDF'yi ayrı ayrı yükle.
9. PGVector için ilk veriden sonra IVFFlat script'ini çalıştır.
10. Aynı soruyla retrieval/rerank/LLM sürelerini karşılaştır.

## Önemli davranışlar

- Background upload job'ları process memory'sindedir; uygulama restart edilirse job geçmişi kaybolur.
- Tek worker kullanılmalıdır. Birden fazla worker kullanırsan in-memory job durumları worker'lar arasında paylaşılmaz.
- Aynı isimli PDF tekrar yüklenebilir; duplicate kontrolü yapılmaz.
- Taranmış/görüntü PDF'lerde OCR yoktur; `pypdf` metin çıkaramıyorsa chunk oluşmaz.
- Embedding boyutu değişirse bütün DB tablo/collection/index yapılarını yeni dimension ile yeniden oluştur.
