#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
[[ -f "$ROOT_DIR/.env" ]] && set -a && source "$ROOT_DIR/.env" && set +a

QDRANT_BASE="${QDRANT_URL:-http://${QDRANT_HOST:-127.0.0.1}:${QDRANT_PORT:-6333}}"
QDRANT_COLLECTION="${QDRANT_COLLECTION:-ai_docs_qdrant}"
EMBEDDING_DIM="${EMBEDDING_DIM:-4096}"
HEADERS=(-H 'Content-Type: application/json')
[[ -n "${QDRANT_API_KEY:-}" ]] && HEADERS+=(-H "api-key: ${QDRANT_API_KEY}")

if curl -fsS "${HEADERS[@]}" "$QDRANT_BASE/collections/$QDRANT_COLLECTION" >/dev/null 2>&1; then
  echo "Qdrant collection already exists: $QDRANT_COLLECTION"
else
  curl -fsS "${HEADERS[@]}" -X PUT "$QDRANT_BASE/collections/$QDRANT_COLLECTION" \
    -d "{\"vectors\":{\"size\":$EMBEDDING_DIM,\"distance\":\"Cosine\"}}"
  echo
  echo "Created Qdrant collection: $QDRANT_COLLECTION"
fi
