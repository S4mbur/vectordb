#!/usr/bin/env python3
"""Create/check Milvus, Qdrant and Elasticsearch structures from .env."""

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from app import (  # noqa: E402
    ES_INDEX,
    MILVUS_COLLECTION,
    QDRANT_COLLECTION,
    ensure_es_index,
    ensure_qdrant_collection,
    get_milvus_collection,
)

milvus = get_milvus_collection()
print(f"Milvus ready: {milvus.name or MILVUS_COLLECTION}")

qdrant = ensure_qdrant_collection()
print(f"Qdrant ready: {QDRANT_COLLECTION}")

elastic = ensure_es_index()
print(f"Elasticsearch ready: {ES_INDEX}; ping={elastic.ping()}")
