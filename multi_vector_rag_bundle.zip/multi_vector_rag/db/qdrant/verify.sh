#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
[[ -f "$ROOT_DIR/.env" ]] && set -a && source "$ROOT_DIR/.env" && set +a
QDRANT_BASE="${QDRANT_URL:-http://${QDRANT_HOST:-127.0.0.1}:${QDRANT_PORT:-6333}}"
QDRANT_COLLECTION="${QDRANT_COLLECTION:-ai_docs_qdrant}"
HEADERS=()
[[ -n "${QDRANT_API_KEY:-}" ]] && HEADERS+=(-H "api-key: ${QDRANT_API_KEY}")
curl -sS "${HEADERS[@]}" "$QDRANT_BASE/collections/$QDRANT_COLLECTION"
echo
