-- Run with psql as a PostgreSQL superuser while connected to the postgres database.
-- Example:
--   psql -h 127.0.0.1 -U postgres -d postgres -f 00_create_database_and_user.sql
-- Change the three values below before running.

\set rag_user 'rag_user'
\set rag_password 'CHANGE_ME'
\set rag_db 'vector_rag'

SELECT format('CREATE ROLE %I LOGIN PASSWORD %L', :'rag_user', :'rag_password')
WHERE NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = :'rag_user')
\gexec

SELECT format('ALTER ROLE %I WITH LOGIN PASSWORD %L', :'rag_user', :'rag_password')
WHERE EXISTS (SELECT 1 FROM pg_roles WHERE rolname = :'rag_user')
\gexec

SELECT format('CREATE DATABASE %I OWNER %I', :'rag_db', :'rag_user')
WHERE NOT EXISTS (SELECT 1 FROM pg_database WHERE datname = :'rag_db')
\gexec

SELECT format('GRANT ALL PRIVILEGES ON DATABASE %I TO %I', :'rag_db', :'rag_user')
\gexec
