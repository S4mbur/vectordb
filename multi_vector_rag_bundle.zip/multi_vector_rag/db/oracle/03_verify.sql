SELECT table_name FROM user_tables WHERE table_name = 'AI_DOCS_ORACLE';

SELECT column_name, data_type, data_length
FROM user_tab_columns
WHERE table_name = 'AI_DOCS_ORACLE'
ORDER BY column_id;

SELECT index_name, index_type, status
FROM user_indexes
WHERE table_name = 'AI_DOCS_ORACLE'
ORDER BY index_name;

SELECT COUNT(*) AS rows, COUNT(DISTINCT file_name) AS files
FROM AI_DOCS_ORACLE;
