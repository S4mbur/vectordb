#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
[[ -f "$ROOT_DIR/.env" ]] && set -a && source "$ROOT_DIR/.env" && set +a
ES_URL="${ES_URL:-http://127.0.0.1:9200}"
ES_INDEX="${ES_INDEX:-ai_docs_elasticsearch}"
AUTH_ARGS=()
[[ -n "${ES_API_KEY:-}" ]] && AUTH_ARGS=(-H "Authorization: ApiKey ${ES_API_KEY}")
[[ -z "${ES_API_KEY:-}" && -n "${ES_USERNAME:-}" && -n "${ES_PASSWORD:-}" ]] && AUTH_ARGS=(-u "${ES_USERNAME}:${ES_PASSWORD}")
curl -sS "${AUTH_ARGS[@]}" "$ES_URL"
echo
curl -sS "${AUTH_ARGS[@]}" "$ES_URL/$ES_INDEX/_mapping"
echo
