#!/usr/bin/env python3
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from app import (  # noqa: E402
    ES_INDEX,
    MILVUS_COLLECTION,
    ORACLE_TABLE,
    PG_TABLE,
    QDRANT_COLLECTION,
    connect_milvus,
    get_es_client,
    get_oracle_connection,
    get_pg_connection,
    get_qdrant_client,
)
from pymilvus import utility  # noqa: E402


def check(name, fn):
    try:
        value = fn()
        print(f"[OK]   {name}: {value}")
    except Exception as exc:
        print(f"[FAIL] {name}: {exc}")


def pg_check():
    conn = get_pg_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(f"SELECT COUNT(*) FROM {PG_TABLE}")
            return f"table={PG_TABLE}, rows={cur.fetchone()[0]}"
    finally:
        conn.close()


def oracle_check():
    conn = get_oracle_connection()
    try:
        cur = conn.cursor()
        cur.execute(f"SELECT COUNT(*) FROM {ORACLE_TABLE}")
        return f"table={ORACLE_TABLE}, rows={cur.fetchone()[0]}"
    finally:
        conn.close()


def milvus_check():
    connect_milvus()
    return f"collection={MILVUS_COLLECTION}, exists={utility.has_collection(MILVUS_COLLECTION)}"


def qdrant_check():
    client = get_qdrant_client()
    names = [x.name for x in client.get_collections().collections]
    return f"collection={QDRANT_COLLECTION}, exists={QDRANT_COLLECTION in names}"


def es_check():
    client = get_es_client()
    return f"ping={client.ping()}, index={ES_INDEX}, exists={bool(client.indices.exists(index=ES_INDEX))}"


check("PostgreSQL", pg_check)
check("Oracle", oracle_check)
check("Milvus", milvus_check)
check("Qdrant", qdrant_check)
check("Elasticsearch", es_check)
